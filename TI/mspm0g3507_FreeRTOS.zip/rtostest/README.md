# MSPM0G3507 FreeRTOS 心跳灯模板

本工程面向 LP-MSPM0G3507，保留一个 FreeRTOS 任务，用于驱动板载蓝灯心跳指示。

## 功能

- GPIO：PB22（SysConfig 标识 `LED2BlueEn`）
- 行为：每 500 ms 翻转一次蓝灯
- 入口：`main_freertos.c`

## 工程组成

- `rtostest`：应用工程，包含 SysConfig、启动文件和心跳任务
- `freertos_builds_LP_MSPM0G3507_release_ticlang`：FreeRTOS 支撑工程

在 Code Composer Studio 中同时导入以上两个工程，并确保已安装 MSPM0 SDK 2.10.00.04、TI Clang 和 SysConfig 1.26.2。

修改引脚或周期时，分别编辑 `empty.syscfg` 和 `main_freertos.c`，然后重新生成 SysConfig 文件并构建。
