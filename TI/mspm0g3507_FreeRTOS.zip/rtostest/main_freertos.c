/*
 * MSPM0G3507 FreeRTOS heartbeat LED example.
 */
#include <stdint.h>

#include <FreeRTOS.h>
#include <task.h>

#include "ti_msp_dl_config.h"

#define HEARTBEAT_TASK_STACK_SIZE    (configMINIMAL_STACK_SIZE)
#define HEARTBEAT_TASK_PRIORITY      (tskIDLE_PRIORITY + 1U)
#define HEARTBEAT_PERIOD_MS          (500U)

static void HeartbeatTask(void *pvParameters)
{
    TickType_t lastWakeTime = xTaskGetTickCount();

    (void) pvParameters;

    for (;;) {
        DL_GPIO_togglePins(BSP_PORT, BSP_LED_PIN);
        vTaskDelayUntil(&lastWakeTime, pdMS_TO_TICKS(HEARTBEAT_PERIOD_MS));
    }
}

int main(void)
{
    SYSCFG_DL_init();

    if (xTaskCreate(HeartbeatTask,
            "Heartbeat",
            HEARTBEAT_TASK_STACK_SIZE,
            NULL,
            HEARTBEAT_TASK_PRIORITY,
            NULL) != pdPASS) {
        taskDISABLE_INTERRUPTS();
        for (;;) {
        }
    }

    vTaskStartScheduler();

    taskDISABLE_INTERRUPTS();
    for (;;) {
    }
}

#if (configCHECK_FOR_STACK_OVERFLOW > 0)
void vApplicationStackOverflowHook(TaskHandle_t task, char *taskName)
{
    (void) task;
    (void) taskName;

    taskDISABLE_INTERRUPTS();
    for (;;) {
    }
}
#endif