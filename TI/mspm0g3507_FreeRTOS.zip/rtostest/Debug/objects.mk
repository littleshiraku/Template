################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -Wl,-l"C:/TI/mspm0_sdk_2_10_00_04/source/ti/drivers/lib/ticlang/m0p/drivers_mspm0g1x0x_g3x0x.a" -Wl,-lfreertos_builds_LP_MSPM0G3507_release_ticlang.lib -Wl,-l"C:/TI/mspm0_sdk_2_10_00_04/source/ti/driverlib/lib/ticlang/m0p/mspm0g1x0x_g3x0x/driverlib.a" -Wl,-llibc.a

